﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using StateMgmtSvc.Models;
using StateMgmtSvc.Services;

namespace StateMgmtSvc.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PayloadController : ControllerBase
    {
        private readonly IPayloadService payloadService;

        public PayloadController(IPayloadService payloadService)
        {
            this.payloadService = payloadService;
        }
        // GET: api/<PayloadsController>
        [HttpGet]
        [EnableQuery]
        public ActionResult<List<Payload>> Get()
        {
            return payloadService.Get();
        }


        // GET api/<PayloadsController>/5
        [HttpGet("{id}")]
        public ActionResult<Payload> Get(int id)
        {
            var payload = payloadService.Get(id);

            if (payload == null)
            {
                return NotFound($"Payload with Id = {id} not found");
            }

            return payload;
        }

        // POST api/<PayloadsController>
        [HttpPost]
        public ActionResult<Payload> Post([FromBody] Payload payload)
        {
            payloadService.Create(payload);

            return CreatedAtAction(nameof(Get), new { id = payload.Id }, payload);
        }

        // PUT api/<PayloadsController>/5
        [HttpPut("{id}")]
        public ActionResult Put(int id, [FromBody] Payload payload)
        {
            var existingPayload = payloadService.Get(id);

            if (existingPayload == null)
            {
                return NotFound($"Payload with Id = {id} not found");
            }

            payloadService.Update(id, payload);

            return NoContent();
        }

        // DELETE api/<PayloadsController>/5
        [HttpDelete("{id}")]
        public ActionResult Delete(int id)
        {
            var payload = payloadService.Get(id);

            if (payload == null)
            {
                return NotFound($"Payload with Id = {id} not found");
            }

            payloadService.Remove(payload.Id);

            return Ok($"Payload with Id = {id} deleted");
        }
    }
}
