﻿namespace StateMgmtSvc.Models
{
    public interface IPayloadStoreDatabaseSettings
    {
        string PayloadCollectionName { get; set; }
        string ConnectionString { get; set; }
        string DatabaseName { get; set; }
    }
}
