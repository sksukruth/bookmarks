﻿namespace StateMgmtSvc.Models;

using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

[BsonIgnoreExtraElements]
public class Payload
{
    [BsonId]
    //[BsonRepresentation(BsonType.ObjectId)]
    //public string Id { get; set; } = String.Empty;
    public int Id { get; set; }

    [BsonElement("useremail")]
    public string UserEmail { get; set; } = String.Empty;

    [BsonElement("tenantid")]
    public string TenantID { get; set; } = String.Empty;

    [BsonElement("advancefilterquery")]
    public List<Advancefilterquery>? advancefilterquery { get; set; }

    public class Advancefilterquery
    {
        [BsonElement("queryname")]
        public string QueryName { get; set; } = String.Empty;

        [BsonElement("querydata")]
        public string queryData { get; set; } = String.Empty;
    }
}

