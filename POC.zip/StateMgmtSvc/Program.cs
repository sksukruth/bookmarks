using Microsoft.AspNetCore.OData;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using StateMgmtSvc.Models;
using StateMgmtSvc.Services;
using System.Configuration;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.Configure<PayloadStoreDatabaseSettings>(
                builder.Configuration.GetSection(nameof(PayloadStoreDatabaseSettings)));

builder.Services.AddSingleton<IPayloadStoreDatabaseSettings>(sp =>
    sp.GetRequiredService<IOptions<PayloadStoreDatabaseSettings>>().Value);

builder.Services.AddSingleton<IMongoClient>(s =>
        new MongoClient(builder.Configuration.GetValue<string>("PayloadStoreDatabaseSettings:ConnectionString")));

builder.Services.AddScoped<IPayloadService, PayloadService>();

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();


builder.Host.ConfigureLogging(logging =>
{
    builder.Services.AddControllersWithViews();
    logging.AddLog4Net(log4NetConfigFile: "C:/projects/StateMgmtSvc/StateMgmtSvc/Configs/log4net.config");
    logging.ClearProviders();
    logging.AddConsole();//for Logging on Console
});


builder.Services.AddControllers().AddOData(options => options.Select().Filter().OrderBy());


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors(x => x
            .AllowAnyOrigin()
            .AllowAnyMethod()
            .AllowAnyHeader());


app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
