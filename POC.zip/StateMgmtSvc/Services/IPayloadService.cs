﻿using StateMgmtSvc.Models;

namespace StateMgmtSvc.Services
{
    public interface IPayloadService
    {
        List<Payload> Get();
        Payload Get(int id);
        Payload Create(Payload payload);
        void Update(int id, Payload payload);
        void Remove(int id);
    }
}
