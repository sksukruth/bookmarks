﻿using Microsoft.AspNetCore.Mvc.ViewFeatures;
using MongoDB.Driver;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using StateMgmtSvc.Models;
using System.ComponentModel;
using System.Text.RegularExpressions;

namespace StateMgmtSvc.Services
{
    public class PayloadService : IPayloadService
    {
        private readonly IMongoCollection<Payload> _payload;

        public PayloadService(IPayloadStoreDatabaseSettings settings, IMongoClient mongoClient)
        {
            var database = mongoClient.GetDatabase(settings.DatabaseName);
            _payload = database.GetCollection<Payload>(settings.PayloadCollectionName);
        }

        public Payload Create(Payload payload)
        {
            _payload.InsertOne(payload);
            return payload;
        }

        public List<Payload> Get()
        {
            return _payload.Find(payload => true).ToList();
        }

        public Payload Get(int id)
        {
            return _payload.Find(payload => payload.Id == id).FirstOrDefault();
        }

        public void Remove(int id)
        {
            _payload.DeleteOne(payload => payload.Id == id);
        }

        public void Update(int id, Payload payload)
        {
            _payload.ReplaceOne(payload => payload.Id == id, payload);
        }
    }
}
